/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 2

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         bnf_parse
#define yylex           bnf_lex
#define yyerror         bnf_error
#define yydebug         bnf_debug
#define yynerrs         bnf_nerrs

/* First part of user prologue.  */
#line 20 "bnf.y"

/* Begin C preamble code */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Absyn.h"

#define YYMAXDEPTH 10000000

/* The type yyscan_t is defined by flex, but we need it in the parser already. */
#ifndef YY_TYPEDEF_YY_SCANNER_T
#define YY_TYPEDEF_YY_SCANNER_T
typedef void* yyscan_t;
#endif

typedef struct yy_buffer_state *YY_BUFFER_STATE;
extern YY_BUFFER_STATE bnf__scan_string(const char *str, yyscan_t scanner);
extern void bnf__delete_buffer(YY_BUFFER_STATE buf, yyscan_t scanner);

extern void bnf_lex_destroy(yyscan_t scanner);
extern char* bnf_get_text(yyscan_t scanner);

extern yyscan_t bnf__initialize_lexer(FILE * inp);

/* List reversal functions. */
ListCOMANDO reverseListCOMANDO(ListCOMANDO l)
{
  ListCOMANDO prev = 0;
  ListCOMANDO tmp = 0;
  while (l)
  {
    tmp = l->listcomando_;
    l->listcomando_ = prev;
    prev = l;
    l = tmp;
  }
  return prev;
}
ListEXP reverseListEXP(ListEXP l)
{
  ListEXP prev = 0;
  ListEXP tmp = 0;
  while (l)
  {
    tmp = l->listexp_;
    l->listexp_ = prev;
    prev = l;
    l = tmp;
  }
  return prev;
}

/* End C preamble code */

#line 132 "Parser.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "Bison.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL__ERROR_ = 3,                    /* _ERROR_  */
  YYSYMBOL__BANGEQ = 4,                    /* _BANGEQ  */
  YYSYMBOL__LPAREN = 5,                    /* _LPAREN  */
  YYSYMBOL__RPAREN = 6,                    /* _RPAREN  */
  YYSYMBOL__STAR = 7,                      /* _STAR  */
  YYSYMBOL__PLUS = 8,                      /* _PLUS  */
  YYSYMBOL__DPLUS = 9,                     /* _DPLUS  */
  YYSYMBOL__COMMA = 10,                    /* _COMMA  */
  YYSYMBOL__MINUS = 11,                    /* _MINUS  */
  YYSYMBOL__SLASH = 12,                    /* _SLASH  */
  YYSYMBOL__SEMI = 13,                     /* _SEMI  */
  YYSYMBOL__LT = 14,                       /* _LT  */
  YYSYMBOL__LDARROW = 15,                  /* _LDARROW  */
  YYSYMBOL__EQ = 16,                       /* _EQ  */
  YYSYMBOL__DEQ = 17,                      /* _DEQ  */
  YYSYMBOL__GT = 18,                       /* _GT  */
  YYSYMBOL__GTEQ = 19,                     /* _GTEQ  */
  YYSYMBOL__KW_Trem = 20,                  /* _KW_Trem  */
  YYSYMBOL__KW_Uai = 21,                   /* _KW_Uai  */
  YYSYMBOL__KW_Zoia = 22,                  /* _KW_Zoia  */
  YYSYMBOL__LBRACK = 23,                   /* _LBRACK  */
  YYSYMBOL__RBRACK = 24,                   /* _RBRACK  */
  YYSYMBOL__SYMB_19 = 25,                  /* _SYMB_19  */
  YYSYMBOL__KW_ceu = 26,                   /* _KW_ceu  */
  YYSYMBOL__KW_deus = 27,                  /* _KW_deus  */
  YYSYMBOL__KW_do = 28,                    /* _KW_do  */
  YYSYMBOL__KW_inteiro = 29,               /* _KW_inteiro  */
  YYSYMBOL__KW_main = 30,                  /* _KW_main  */
  YYSYMBOL__KW_real = 31,                  /* _KW_real  */
  YYSYMBOL__KW_texto = 32,                 /* _KW_texto  */
  YYSYMBOL__LBRACE = 33,                   /* _LBRACE  */
  YYSYMBOL__RBRACE = 34,                   /* _RBRACE  */
  YYSYMBOL_T_Identificador = 35,           /* T_Identificador  */
  YYSYMBOL_T_Inteiro = 36,                 /* T_Inteiro  */
  YYSYMBOL_T_Real = 37,                    /* T_Real  */
  YYSYMBOL_T_Texto = 38,                   /* T_Texto  */
  YYSYMBOL_YYACCEPT = 39,                  /* $accept  */
  YYSYMBOL_Programa = 40,                  /* Programa  */
  YYSYMBOL_BlocoComandos = 41,             /* BlocoComandos  */
  YYSYMBOL_ListCOMANDO = 42,               /* ListCOMANDO  */
  YYSYMBOL_COMANDO = 43,                   /* COMANDO  */
  YYSYMBOL_COMANDO_SIMPLES = 44,           /* COMANDO_SIMPLES  */
  YYSYMBOL_COMANDO_COMPOSTO = 45,          /* COMANDO_COMPOSTO  */
  YYSYMBOL_ATRIB = 46,                     /* ATRIB  */
  YYSYMBOL_EXP = 47,                       /* EXP  */
  YYSYMBOL_CONDICIONAL = 48,               /* CONDICIONAL  */
  YYSYMBOL_REPETE = 49,                    /* REPETE  */
  YYSYMBOL_IMPRIME = 50,                   /* IMPRIME  */
  YYSYMBOL_CondicaoExpressao = 51,         /* CondicaoExpressao  */
  YYSYMBOL_OpRel = 52,                     /* OpRel  */
  YYSYMBOL_OpArit = 53,                    /* OpArit  */
  YYSYMBOL_VALOR = 54,                     /* VALOR  */
  YYSYMBOL_Tipo = 55,                      /* Tipo  */
  YYSYMBOL_AcessoVetor = 56,               /* AcessoVetor  */
  YYSYMBOL_LinhasDeMatriz = 57,            /* LinhasDeMatriz  */
  YYSYMBOL_LinhaDeMatriz = 58,             /* LinhaDeMatriz  */
  YYSYMBOL_ListEXP = 59                    /* ListEXP  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;


/* Second part of user prologue.  */
#line 104 "bnf.y"

void yyerror(YYLTYPE *loc, yyscan_t scanner, YYSTYPE *result, const char *msg)
{
  fprintf(stderr, "error: %d,%d: %s at %s\n",
    loc->first_line, loc->first_column, msg, bnf_get_text(scanner));
}

int yyparse(yyscan_t scanner, YYSTYPE *result);

extern int yylex(YYSTYPE *lvalp, YYLTYPE *llocp, yyscan_t scanner);

#line 237 "Parser.c"


#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
             && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   134

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  39
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  21
/* YYNRULES -- Number of rules.  */
#define YYNRULES  53
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  117

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   293


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint8 yyrline[] =
{
       0,   178,   178,   180,   182,   183,   185,   186,   188,   189,
     190,   192,   193,   195,   196,   197,   198,   199,   200,   201,
     203,   204,   205,   206,   208,   210,   211,   213,   215,   217,
     218,   219,   220,   221,   222,   224,   225,   226,   227,   229,
     230,   231,   232,   233,   235,   236,   237,   239,   240,   242,
     243,   245,   247,   248
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "_ERROR_", "_BANGEQ",
  "_LPAREN", "_RPAREN", "_STAR", "_PLUS", "_DPLUS", "_COMMA", "_MINUS",
  "_SLASH", "_SEMI", "_LT", "_LDARROW", "_EQ", "_DEQ", "_GT", "_GTEQ",
  "_KW_Trem", "_KW_Uai", "_KW_Zoia", "_LBRACK", "_RBRACK", "_SYMB_19",
  "_KW_ceu", "_KW_deus", "_KW_do", "_KW_inteiro", "_KW_main", "_KW_real",
  "_KW_texto", "_LBRACE", "_RBRACE", "T_Identificador", "T_Inteiro",
  "T_Real", "T_Texto", "$accept", "Programa", "BlocoComandos",
  "ListCOMANDO", "COMANDO", "COMANDO_SIMPLES", "COMANDO_COMPOSTO", "ATRIB",
  "EXP", "CONDICIONAL", "REPETE", "IMPRIME", "CondicaoExpressao", "OpRel",
  "OpArit", "VALOR", "Tipo", "AcessoVetor", "LinhasDeMatriz",
  "LinhaDeMatriz", "ListEXP", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-69)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int8 yypact[] =
{
     -23,    -6,    30,     7,   -69,    14,    11,   -69,   -69,   -18,
      50,    52,    55,   -69,   -69,   -69,   -69,    15,   -69,   -69,
     -69,   -69,    60,   -69,   -69,    97,   -69,   -69,   -69,   -69,
      44,    -1,    65,    75,    75,   -69,    75,    75,   -69,   -69,
     -69,   -69,   -69,    75,    13,   -69,    75,    54,    49,     3,
      57,    82,    76,    35,    97,    -2,    97,    75,    71,    97,
      75,    77,   -69,   -69,   -69,   -69,   -69,   -69,    75,    11,
     -69,   -69,    75,    97,     8,    70,    75,    97,   -69,    42,
      90,    78,    75,    79,   -69,    92,    93,   103,    75,    75,
     102,    84,   107,    91,    98,   100,   112,    89,    75,   -69,
     104,   119,   117,   -69,    75,   105,   118,    11,   124,   108,
     -69,   104,   -69,    11,   -69,   -69,   -69
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     1,     0,     0,     4,     2,     0,
       0,     0,     0,    44,    45,    46,     3,    39,    40,    41,
      42,     5,     0,     7,     8,     9,    11,    12,    10,    22,
       0,    43,     0,     0,     0,    20,     0,     0,     6,    37,
      35,    36,    38,     0,     0,    21,     0,     0,     0,    39,
       0,     0,    43,     0,    14,     0,    23,     0,     0,    15,
       0,     0,    34,    31,    32,    33,    29,    30,     0,     0,
      27,    47,     0,    13,     0,     0,     0,    28,    24,     0,
      16,     0,     0,     0,    48,     0,     0,     0,     0,     0,
      18,     0,     0,    52,     0,     0,     0,     0,     0,    17,
       0,     0,     0,    53,     0,     0,    49,     0,     0,     0,
      19,     0,    26,     0,    51,    50,    25
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
     -69,   -69,   -68,   -69,   -69,   -69,   -69,   -69,    -9,   -69,
     -69,   -69,   -30,   -69,   -69,   -69,    99,   125,    22,   -69,
     -42
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
       0,     2,     8,     9,    21,    22,    23,    24,    50,    26,
      27,    28,    51,    68,    43,    29,    30,    52,   105,   106,
      94
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int8 yytable[] =
{
      25,    78,    10,    11,    12,    39,    40,     1,    45,    41,
      42,    13,    35,    14,    15,    46,    16,    17,    18,    19,
      20,     3,    71,    72,    35,    53,    37,    54,    55,    57,
       4,    36,    80,    81,    56,     5,    58,    59,    37,   112,
       6,    70,    39,    40,     7,   116,    41,    42,    73,    39,
      40,    75,    87,    41,    42,    32,   103,    33,    92,    77,
      34,    62,   109,    79,    39,    40,    84,    83,    41,    42,
      60,    63,    64,    38,    65,    66,    67,    39,    40,    44,
      93,    41,    42,    82,    61,    45,    39,    40,    69,    93,
      41,    42,    88,    76,    13,    93,    14,    15,    39,    40,
      47,    98,    41,    42,    39,    40,    85,    74,    41,    42,
      49,    18,    19,    20,    86,    89,    91,    90,    95,    96,
      97,   101,    99,   100,   102,   107,   108,   104,   111,   110,
     113,    48,   114,   115,    31
};

static const yytype_int8 yycheck[] =
{
       9,    69,    20,    21,    22,     7,     8,    30,     9,    11,
      12,    29,     9,    31,    32,    16,    34,    35,    36,    37,
      38,    27,    24,    25,     9,    34,    23,    36,    37,    16,
       0,    16,    24,    25,    43,    28,    23,    46,    23,   107,
      26,     6,     7,     8,    33,   113,    11,    12,    57,     7,
       8,    60,    82,    11,    12,     5,    98,     5,    88,    68,
       5,     4,   104,    72,     7,     8,    24,    76,    11,    12,
      16,    14,    15,    13,    17,    18,    19,     7,     8,    35,
      89,    11,    12,    13,    35,     9,     7,     8,     6,    98,
      11,    12,    13,    16,    29,   104,    31,    32,     7,     8,
      35,    10,    11,    12,     7,     8,    16,    36,    11,    12,
      35,    36,    37,    38,    36,    23,    13,    24,    16,    35,
      13,     9,    24,    23,    35,     6,     9,    23,    10,    24,
       6,    32,    24,   111,     9
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    30,    40,    27,     0,    28,    26,    33,    41,    42,
      20,    21,    22,    29,    31,    32,    34,    35,    36,    37,
      38,    43,    44,    45,    46,    47,    48,    49,    50,    54,
      55,    56,     5,     5,     5,     9,    16,    23,    13,     7,
       8,    11,    12,    53,    35,     9,    16,    35,    55,    35,
      47,    51,    56,    47,    47,    47,    47,    16,    23,    47,
      16,    35,     4,    14,    15,    17,    18,    19,    52,     6,
       6,    24,    25,    47,    36,    47,    16,    47,    41,    47,
      24,    25,    13,    47,    24,    16,    36,    51,    13,    23,
      24,    13,    51,    47,    59,    16,    35,    13,    10,    24,
      23,     9,    35,    59,    23,    57,    58,     6,     9,    59,
      24,    10,    41,     6,    24,    57,    41
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    39,    40,    41,    42,    42,    43,    43,    44,    44,
      44,    45,    45,    46,    46,    46,    46,    46,    46,    46,
      47,    47,    47,    47,    48,    49,    49,    50,    51,    52,
      52,    52,    52,    52,    52,    53,    53,    53,    53,    54,
      54,    54,    54,    54,    55,    55,    55,    56,    56,    57,
      57,    58,    59,    59
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     5,     3,     0,     2,     2,     1,     1,     1,
       1,     1,     1,     4,     3,     3,     5,     9,     7,    11,
       2,     2,     1,     3,     5,    13,    12,     4,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     4,     6,     1,
       3,     3,     1,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, scanner, result, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, scanner, result); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, yyscan_t scanner, YYSTYPE *result)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (scanner);
  YY_USE (result);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, yyscan_t scanner, YYSTYPE *result)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, scanner, result);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, yyscan_t scanner, YYSTYPE *result)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), scanner, result);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, scanner, result); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, yyscan_t scanner, YYSTYPE *result)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (scanner);
  YY_USE (result);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (yyscan_t scanner, YYSTYPE *result)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, scanner);
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* Programa: _KW_main _KW_deus _KW_do _KW_ceu BlocoComandos  */
#line 178 "bnf.y"
                                                          { (yyval.programa_) = make_Inicio((yyvsp[0].blococomandos_)); result->programa_ = (yyval.programa_); }
#line 1397 "Parser.c"
    break;

  case 3: /* BlocoComandos: _LBRACE ListCOMANDO _RBRACE  */
#line 180 "bnf.y"
                                            { (yyval.blococomandos_) = make_Bloco(reverseListCOMANDO((yyvsp[-1].listcomando_))); result->blococomandos_ = (yyval.blococomandos_); }
#line 1403 "Parser.c"
    break;

  case 4: /* ListCOMANDO: %empty  */
#line 182 "bnf.y"
                          { (yyval.listcomando_) = 0; result->listcomando_ = (yyval.listcomando_); }
#line 1409 "Parser.c"
    break;

  case 5: /* ListCOMANDO: ListCOMANDO COMANDO  */
#line 183 "bnf.y"
                        { (yyval.listcomando_) = make_ListCOMANDO((yyvsp[0].comando_), (yyvsp[-1].listcomando_)); result->listcomando_ = (yyval.listcomando_); }
#line 1415 "Parser.c"
    break;

  case 6: /* COMANDO: COMANDO_SIMPLES _SEMI  */
#line 185 "bnf.y"
                                { (yyval.comando_) = make_COMANDO1((yyvsp[-1].comando_simples_)); result->comando_ = (yyval.comando_); }
#line 1421 "Parser.c"
    break;

  case 7: /* COMANDO: COMANDO_COMPOSTO  */
#line 186 "bnf.y"
                     { (yyval.comando_) = make_COMANDOCOMANDO_COMPOSTO((yyvsp[0].comando_composto_)); result->comando_ = (yyval.comando_); }
#line 1427 "Parser.c"
    break;

  case 8: /* COMANDO_SIMPLES: ATRIB  */
#line 188 "bnf.y"
                        { (yyval.comando_simples_) = make_COMANDO_SIMPLESATRIB((yyvsp[0].atrib_)); result->comando_simples_ = (yyval.comando_simples_); }
#line 1433 "Parser.c"
    break;

  case 9: /* COMANDO_SIMPLES: EXP  */
#line 189 "bnf.y"
        { (yyval.comando_simples_) = make_COMANDO_SIMPLESEXP((yyvsp[0].exp_)); result->comando_simples_ = (yyval.comando_simples_); }
#line 1439 "Parser.c"
    break;

  case 10: /* COMANDO_SIMPLES: IMPRIME  */
#line 190 "bnf.y"
            { (yyval.comando_simples_) = make_COMANDO_SIMPLESIMPRIME((yyvsp[0].imprime_)); result->comando_simples_ = (yyval.comando_simples_); }
#line 1445 "Parser.c"
    break;

  case 11: /* COMANDO_COMPOSTO: CONDICIONAL  */
#line 192 "bnf.y"
                               { (yyval.comando_composto_) = make_COMANDO_COMPOSTOCONDICIONAL((yyvsp[0].condicional_)); result->comando_composto_ = (yyval.comando_composto_); }
#line 1451 "Parser.c"
    break;

  case 12: /* COMANDO_COMPOSTO: REPETE  */
#line 193 "bnf.y"
           { (yyval.comando_composto_) = make_COMANDO_COMPOSTOREPETE((yyvsp[0].repete_)); result->comando_composto_ = (yyval.comando_composto_); }
#line 1457 "Parser.c"
    break;

  case 13: /* ATRIB: Tipo T_Identificador _EQ EXP  */
#line 195 "bnf.y"
                                     { (yyval.atrib_) = make_Declara((yyvsp[-3].tipo_), (yyvsp[-2]._string), (yyvsp[0].exp_)); result->atrib_ = (yyval.atrib_); }
#line 1463 "Parser.c"
    break;

  case 14: /* ATRIB: T_Identificador _EQ EXP  */
#line 196 "bnf.y"
                            { (yyval.atrib_) = make_Atribui((yyvsp[-2]._string), (yyvsp[0].exp_)); result->atrib_ = (yyval.atrib_); }
#line 1469 "Parser.c"
    break;

  case 15: /* ATRIB: AcessoVetor _EQ EXP  */
#line 197 "bnf.y"
                        { (yyval.atrib_) = make_AtribuiVetor((yyvsp[-2].acessovetor_), (yyvsp[0].exp_)); result->atrib_ = (yyval.atrib_); }
#line 1475 "Parser.c"
    break;

  case 16: /* ATRIB: Tipo T_Identificador _LBRACK T_Inteiro _RBRACK  */
#line 198 "bnf.y"
                                                   { (yyval.atrib_) = make_DeclaraVetor((yyvsp[-4].tipo_), (yyvsp[-3]._string), (yyvsp[-1]._string)); result->atrib_ = (yyval.atrib_); }
#line 1481 "Parser.c"
    break;

  case 17: /* ATRIB: Tipo T_Identificador _LBRACK T_Inteiro _RBRACK _EQ _LBRACK ListEXP _RBRACK  */
#line 199 "bnf.y"
                                                                               { (yyval.atrib_) = make_InicializaVetor((yyvsp[-8].tipo_), (yyvsp[-7]._string), (yyvsp[-5]._string), (yyvsp[-1].listexp_)); result->atrib_ = (yyval.atrib_); }
#line 1487 "Parser.c"
    break;

  case 18: /* ATRIB: Tipo T_Identificador _LBRACK T_Inteiro _SYMB_19 T_Inteiro _RBRACK  */
#line 200 "bnf.y"
                                                                      { (yyval.atrib_) = make_DeclaraMatriz((yyvsp[-6].tipo_), (yyvsp[-5]._string), (yyvsp[-3]._string), (yyvsp[-1]._string)); result->atrib_ = (yyval.atrib_); }
#line 1493 "Parser.c"
    break;

  case 19: /* ATRIB: Tipo T_Identificador _LBRACK T_Inteiro _SYMB_19 T_Inteiro _RBRACK _EQ _LBRACK LinhasDeMatriz _RBRACK  */
#line 201 "bnf.y"
                                                                                                         { (yyval.atrib_) = make_InicializaMatriz((yyvsp[-10].tipo_), (yyvsp[-9]._string), (yyvsp[-7]._string), (yyvsp[-5]._string), (yyvsp[-1].linhasdematriz_)); result->atrib_ = (yyval.atrib_); }
#line 1499 "Parser.c"
    break;

  case 20: /* EXP: T_Identificador _DPLUS  */
#line 203 "bnf.y"
                             { (yyval.exp_) = make_IncVar((yyvsp[-1]._string)); result->exp_ = (yyval.exp_); }
#line 1505 "Parser.c"
    break;

  case 21: /* EXP: AcessoVetor _DPLUS  */
#line 204 "bnf.y"
                       { (yyval.exp_) = make_IncVetor((yyvsp[-1].acessovetor_)); result->exp_ = (yyval.exp_); }
#line 1511 "Parser.c"
    break;

  case 22: /* EXP: VALOR  */
#line 205 "bnf.y"
          { (yyval.exp_) = make_Valor((yyvsp[0].valor_)); result->exp_ = (yyval.exp_); }
#line 1517 "Parser.c"
    break;

  case 23: /* EXP: EXP OpArit EXP  */
#line 206 "bnf.y"
                   { (yyval.exp_) = make_Operacao((yyvsp[-2].exp_), (yyvsp[-1].oparit_), (yyvsp[0].exp_)); result->exp_ = (yyval.exp_); }
#line 1523 "Parser.c"
    break;

  case 24: /* CONDICIONAL: _KW_Uai _LPAREN CondicaoExpressao _RPAREN BlocoComandos  */
#line 208 "bnf.y"
                                                                      { (yyval.condicional_) = make_Se((yyvsp[-2].condicaoexpressao_), (yyvsp[0].blococomandos_)); result->condicional_ = (yyval.condicional_); }
#line 1529 "Parser.c"
    break;

  case 25: /* REPETE: _KW_Trem _LPAREN Tipo T_Identificador _EQ EXP _SEMI CondicaoExpressao _SEMI T_Identificador _DPLUS _RPAREN BlocoComandos  */
#line 210 "bnf.y"
                                                                                                                                  { (yyval.repete_) = make_ParaTipo((yyvsp[-10].tipo_), (yyvsp[-9]._string), (yyvsp[-7].exp_), (yyvsp[-5].condicaoexpressao_), (yyvsp[-3]._string), (yyvsp[0].blococomandos_)); result->repete_ = (yyval.repete_); }
#line 1535 "Parser.c"
    break;

  case 26: /* REPETE: _KW_Trem _LPAREN T_Identificador _EQ EXP _SEMI CondicaoExpressao _SEMI T_Identificador _DPLUS _RPAREN BlocoComandos  */
#line 211 "bnf.y"
                                                                                                                        { (yyval.repete_) = make_Para((yyvsp[-9]._string), (yyvsp[-7].exp_), (yyvsp[-5].condicaoexpressao_), (yyvsp[-3]._string), (yyvsp[0].blococomandos_)); result->repete_ = (yyval.repete_); }
#line 1541 "Parser.c"
    break;

  case 27: /* IMPRIME: _KW_Zoia _LPAREN EXP _RPAREN  */
#line 213 "bnf.y"
                                       { (yyval.imprime_) = make_Imprime((yyvsp[-1].exp_)); result->imprime_ = (yyval.imprime_); }
#line 1547 "Parser.c"
    break;

  case 28: /* CondicaoExpressao: EXP OpRel EXP  */
#line 215 "bnf.y"
                                  { (yyval.condicaoexpressao_) = make_CondicaoExpr((yyvsp[-2].exp_), (yyvsp[-1].oprel_), (yyvsp[0].exp_)); result->condicaoexpressao_ = (yyval.condicaoexpressao_); }
#line 1553 "Parser.c"
    break;

  case 29: /* OpRel: _GT  */
#line 217 "bnf.y"
            { (yyval.oprel_) = make_Maior(); result->oprel_ = (yyval.oprel_); }
#line 1559 "Parser.c"
    break;

  case 30: /* OpRel: _GTEQ  */
#line 218 "bnf.y"
          { (yyval.oprel_) = make_MaiorIgual(); result->oprel_ = (yyval.oprel_); }
#line 1565 "Parser.c"
    break;

  case 31: /* OpRel: _LT  */
#line 219 "bnf.y"
        { (yyval.oprel_) = make_Menor(); result->oprel_ = (yyval.oprel_); }
#line 1571 "Parser.c"
    break;

  case 32: /* OpRel: _LDARROW  */
#line 220 "bnf.y"
             { (yyval.oprel_) = make_MenorIgual(); result->oprel_ = (yyval.oprel_); }
#line 1577 "Parser.c"
    break;

  case 33: /* OpRel: _DEQ  */
#line 221 "bnf.y"
         { (yyval.oprel_) = make_Igual(); result->oprel_ = (yyval.oprel_); }
#line 1583 "Parser.c"
    break;

  case 34: /* OpRel: _BANGEQ  */
#line 222 "bnf.y"
            { (yyval.oprel_) = make_Diferente(); result->oprel_ = (yyval.oprel_); }
#line 1589 "Parser.c"
    break;

  case 35: /* OpArit: _PLUS  */
#line 224 "bnf.y"
               { (yyval.oparit_) = make_Soma(); result->oparit_ = (yyval.oparit_); }
#line 1595 "Parser.c"
    break;

  case 36: /* OpArit: _MINUS  */
#line 225 "bnf.y"
           { (yyval.oparit_) = make_Subtrai(); result->oparit_ = (yyval.oparit_); }
#line 1601 "Parser.c"
    break;

  case 37: /* OpArit: _STAR  */
#line 226 "bnf.y"
          { (yyval.oparit_) = make_Multiplica(); result->oparit_ = (yyval.oparit_); }
#line 1607 "Parser.c"
    break;

  case 38: /* OpArit: _SLASH  */
#line 227 "bnf.y"
           { (yyval.oparit_) = make_Divide(); result->oparit_ = (yyval.oparit_); }
#line 1613 "Parser.c"
    break;

  case 39: /* VALOR: T_Identificador  */
#line 229 "bnf.y"
                        { (yyval.valor_) = make_ValorIdent((yyvsp[0]._string)); result->valor_ = (yyval.valor_); }
#line 1619 "Parser.c"
    break;

  case 40: /* VALOR: T_Inteiro  */
#line 230 "bnf.y"
              { (yyval.valor_) = make_ValorInteiro((yyvsp[0]._string)); result->valor_ = (yyval.valor_); }
#line 1625 "Parser.c"
    break;

  case 41: /* VALOR: T_Real  */
#line 231 "bnf.y"
           { (yyval.valor_) = make_ValorReal((yyvsp[0]._string)); result->valor_ = (yyval.valor_); }
#line 1631 "Parser.c"
    break;

  case 42: /* VALOR: T_Texto  */
#line 232 "bnf.y"
            { (yyval.valor_) = make_ValorTexto((yyvsp[0]._string)); result->valor_ = (yyval.valor_); }
#line 1637 "Parser.c"
    break;

  case 43: /* VALOR: AcessoVetor  */
#line 233 "bnf.y"
                { (yyval.valor_) = make_ValorVetor((yyvsp[0].acessovetor_)); result->valor_ = (yyval.valor_); }
#line 1643 "Parser.c"
    break;

  case 44: /* Tipo: _KW_inteiro  */
#line 235 "bnf.y"
                   { (yyval.tipo_) = make_TipoInt(); result->tipo_ = (yyval.tipo_); }
#line 1649 "Parser.c"
    break;

  case 45: /* Tipo: _KW_real  */
#line 236 "bnf.y"
             { (yyval.tipo_) = make_TipoReal(); result->tipo_ = (yyval.tipo_); }
#line 1655 "Parser.c"
    break;

  case 46: /* Tipo: _KW_texto  */
#line 237 "bnf.y"
              { (yyval.tipo_) = make_TipoTexto(); result->tipo_ = (yyval.tipo_); }
#line 1661 "Parser.c"
    break;

  case 47: /* AcessoVetor: T_Identificador _LBRACK EXP _RBRACK  */
#line 239 "bnf.y"
                                                  { (yyval.acessovetor_) = make_AcessoSimples((yyvsp[-3]._string), (yyvsp[-1].exp_)); result->acessovetor_ = (yyval.acessovetor_); }
#line 1667 "Parser.c"
    break;

  case 48: /* AcessoVetor: T_Identificador _LBRACK EXP _SYMB_19 EXP _RBRACK  */
#line 240 "bnf.y"
                                                     { (yyval.acessovetor_) = make_AcessoMatriz((yyvsp[-5]._string), (yyvsp[-3].exp_), (yyvsp[-1].exp_)); result->acessovetor_ = (yyval.acessovetor_); }
#line 1673 "Parser.c"
    break;

  case 49: /* LinhasDeMatriz: LinhaDeMatriz  */
#line 242 "bnf.y"
                               { (yyval.linhasdematriz_) = make_LinhaSimples((yyvsp[0].linhadematriz_)); result->linhasdematriz_ = (yyval.linhasdematriz_); }
#line 1679 "Parser.c"
    break;

  case 50: /* LinhasDeMatriz: LinhaDeMatriz _COMMA LinhasDeMatriz  */
#line 243 "bnf.y"
                                        { (yyval.linhasdematriz_) = make_LinhasMultiplas((yyvsp[-2].linhadematriz_), (yyvsp[0].linhasdematriz_)); result->linhasdematriz_ = (yyval.linhasdematriz_); }
#line 1685 "Parser.c"
    break;

  case 51: /* LinhaDeMatriz: _LBRACK ListEXP _RBRACK  */
#line 245 "bnf.y"
                                        { (yyval.linhadematriz_) = make_LinhaUnica((yyvsp[-1].listexp_)); result->linhadematriz_ = (yyval.linhadematriz_); }
#line 1691 "Parser.c"
    break;

  case 52: /* ListEXP: EXP  */
#line 247 "bnf.y"
              { (yyval.listexp_) = make_ListEXP((yyvsp[0].exp_), 0); result->listexp_ = (yyval.listexp_); }
#line 1697 "Parser.c"
    break;

  case 53: /* ListEXP: EXP _COMMA ListEXP  */
#line 248 "bnf.y"
                       { (yyval.listexp_) = make_ListEXP((yyvsp[-2].exp_), (yyvsp[0].listexp_)); result->listexp_ = (yyval.listexp_); }
#line 1703 "Parser.c"
    break;


#line 1707 "Parser.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (&yylloc, scanner, result, YY_("syntax error"));
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, scanner, result);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, scanner, result);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, scanner, result, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, scanner, result);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, scanner, result);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 251 "bnf.y"



/* Entrypoint: parse Programa from file. */
Programa pPrograma(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.programa_;
  }
}

/* Entrypoint: parse Programa from string. */
Programa psPrograma(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.programa_;
  }
}

/* Entrypoint: parse BlocoComandos from file. */
BlocoComandos pBlocoComandos(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.blococomandos_;
  }
}

/* Entrypoint: parse BlocoComandos from string. */
BlocoComandos psBlocoComandos(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.blococomandos_;
  }
}

/* Entrypoint: parse ListCOMANDO from file. */
ListCOMANDO pListCOMANDO(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return reverseListCOMANDO(result.listcomando_);
  }
}

/* Entrypoint: parse ListCOMANDO from string. */
ListCOMANDO psListCOMANDO(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return reverseListCOMANDO(result.listcomando_);
  }
}

/* Entrypoint: parse COMANDO from file. */
COMANDO pCOMANDO(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_;
  }
}

/* Entrypoint: parse COMANDO from string. */
COMANDO psCOMANDO(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_;
  }
}

/* Entrypoint: parse COMANDO_SIMPLES from file. */
COMANDO_SIMPLES pCOMANDO_SIMPLES(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_simples_;
  }
}

/* Entrypoint: parse COMANDO_SIMPLES from string. */
COMANDO_SIMPLES psCOMANDO_SIMPLES(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_simples_;
  }
}

/* Entrypoint: parse COMANDO_COMPOSTO from file. */
COMANDO_COMPOSTO pCOMANDO_COMPOSTO(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_composto_;
  }
}

/* Entrypoint: parse COMANDO_COMPOSTO from string. */
COMANDO_COMPOSTO psCOMANDO_COMPOSTO(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.comando_composto_;
  }
}

/* Entrypoint: parse ATRIB from file. */
ATRIB pATRIB(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.atrib_;
  }
}

/* Entrypoint: parse ATRIB from string. */
ATRIB psATRIB(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.atrib_;
  }
}

/* Entrypoint: parse EXP from file. */
EXP pEXP(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.exp_;
  }
}

/* Entrypoint: parse EXP from string. */
EXP psEXP(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.exp_;
  }
}

/* Entrypoint: parse CONDICIONAL from file. */
CONDICIONAL pCONDICIONAL(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.condicional_;
  }
}

/* Entrypoint: parse CONDICIONAL from string. */
CONDICIONAL psCONDICIONAL(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.condicional_;
  }
}

/* Entrypoint: parse REPETE from file. */
REPETE pREPETE(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.repete_;
  }
}

/* Entrypoint: parse REPETE from string. */
REPETE psREPETE(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.repete_;
  }
}

/* Entrypoint: parse IMPRIME from file. */
IMPRIME pIMPRIME(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.imprime_;
  }
}

/* Entrypoint: parse IMPRIME from string. */
IMPRIME psIMPRIME(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.imprime_;
  }
}

/* Entrypoint: parse CondicaoExpressao from file. */
CondicaoExpressao pCondicaoExpressao(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.condicaoexpressao_;
  }
}

/* Entrypoint: parse CondicaoExpressao from string. */
CondicaoExpressao psCondicaoExpressao(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.condicaoexpressao_;
  }
}

/* Entrypoint: parse OpRel from file. */
OpRel pOpRel(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.oprel_;
  }
}

/* Entrypoint: parse OpRel from string. */
OpRel psOpRel(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.oprel_;
  }
}

/* Entrypoint: parse OpArit from file. */
OpArit pOpArit(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.oparit_;
  }
}

/* Entrypoint: parse OpArit from string. */
OpArit psOpArit(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.oparit_;
  }
}

/* Entrypoint: parse VALOR from file. */
VALOR pVALOR(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.valor_;
  }
}

/* Entrypoint: parse VALOR from string. */
VALOR psVALOR(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.valor_;
  }
}

/* Entrypoint: parse Tipo from file. */
Tipo pTipo(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.tipo_;
  }
}

/* Entrypoint: parse Tipo from string. */
Tipo psTipo(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.tipo_;
  }
}

/* Entrypoint: parse AcessoVetor from file. */
AcessoVetor pAcessoVetor(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.acessovetor_;
  }
}

/* Entrypoint: parse AcessoVetor from string. */
AcessoVetor psAcessoVetor(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.acessovetor_;
  }
}

/* Entrypoint: parse LinhasDeMatriz from file. */
LinhasDeMatriz pLinhasDeMatriz(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.linhasdematriz_;
  }
}

/* Entrypoint: parse LinhasDeMatriz from string. */
LinhasDeMatriz psLinhasDeMatriz(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.linhasdematriz_;
  }
}

/* Entrypoint: parse LinhaDeMatriz from file. */
LinhaDeMatriz pLinhaDeMatriz(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.linhadematriz_;
  }
}

/* Entrypoint: parse LinhaDeMatriz from string. */
LinhaDeMatriz psLinhaDeMatriz(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.linhadematriz_;
  }
}

/* Entrypoint: parse ListEXP from file. */
ListEXP pListEXP(FILE *inp)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(inp);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  int error = yyparse(scanner, &result);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.listexp_;
  }
}

/* Entrypoint: parse ListEXP from string. */
ListEXP psListEXP(const char *str)
{
  YYSTYPE result;
  yyscan_t scanner = bnf__initialize_lexer(0);
  if (!scanner) {
    fprintf(stderr, "Failed to initialize lexer.\n");
    return 0;
  }
  YY_BUFFER_STATE buf = bnf__scan_string(str, scanner);
  int error = yyparse(scanner, &result);
  bnf__delete_buffer(buf, scanner);
  bnf_lex_destroy(scanner);
  if (error)
  { /* Failure */
    return 0;
  }
  else
  { /* Success */
    return result.listexp_;
  }
}



